%%%
%
%The following script will load .tif images, perform simple image processing
%on the images, find peaks by intensity, determine Region of Interest (ROI)
%points using and then estimate the peaks' x/y lengths using a GaussFit
%routine that uses a full-width half-max approximation of the fit. 
%
%   Code modified from E.A. Gibson (2014)
%   Authors: Mohamed Abdel-Hafiz, Thomas Fox
%
% Variable inputs:
%   clim (line 75) - sets color limit values for peak finding
%   thres (line 76) - sets intensity threshold for peak finding
%   densityfactor (line 91) - sets absolute value for pixel distance surrounding peaks
%   minimumpixels (line 92) - sets minimum pixel number for density filtering
%   pixel (line 123) - sets the absolute value for distance length of ROI surrounding peaks
%
%% Load image

clear all
close all

%Need to read in a tif file with a colormap: the tif is a grayscale file
%and the colormap is a vector of 3 that determines the color.
%
%Select which image to process by un-commenting the line. Ensure the
%correct pixel area is loaded for the image to be processed.

%Images on Thomas' computer
%[cdata_647,map] = imread('C:\Users\The Tom Fox\Documents\MATLAB\SpectralOrangeSmall_HuFixedBrain_488Exc_ZTile_1.tif');
%[cdata_647,map] = imread('C:\Users\The Tom Fox\Documents\MATLAB\SpectralGreenSmall_HuFixedBrain_488Exc_ZTile_1.tif');
%[cdata_647,map] = imread('C:\Users\The Tom Fox\Documents\MATLAB\SpectralRedSmall_HuFixedBrain_488Exc_ZTile_1.tif');
[cdata_647,map] = imread('C:\Users\The Tom Fox\Documents\MATLAB\CompositeSmall_HuFixedBrain_488Exc_ZTile_1.tif');
pixelarea = (8668/1600)*(7040.69/1300); %Pixel area for 488Exc_ZTile image tiff set. 

%Images on Mohamed's computuer
%[cdata_647,map] = imread('C:\Users\dahli\Documents\School\Summer 2017\Image Processing\SpectralOrange_HuFixedBrain_561Exc_ZTile_1.tif');
%[cdata_647,map] = imread('C:\Users\dahli\Documents\School\Summer 2017\Image Processing\HuBrain_20170630_250um_Confocal_DSP_Cropped.tif');
%[cdata,map] = imread(fullfile(p,f));

%Correct any problems with non-grescale images
grayImage = cdata_647;
if ndims(grayImage) >= 3
    grayImage = rgb2gray(grayImage(:, :, 1:3));
end

%% Basic Image Processing
% 
% %Determine image background
% background = imopen(cdata_647,strel('disk',15));
% 
% %Display the background
% figure();
% surf(double(background(1:8:end,1:8:end)));
% ax = gca;
% ax.YDir = 'reverse';
% title('Image Background');
% 
% %Subtract the background from image
% cdata_647 = imtophat(grayImage,strel('disk',500));
% 
% %Display the subtracted image
% figure(); imshow(cdata_647)
% title('Subtracted background');
% 
%Histrogram equilization, increase image contrast
cdata_647 = adapthisteq(cdata_647);

%Display the equalized image
figure(); imshow(cdata_647);
title('Adaptive Histogram Equilization');

%% Call FastPeakFind function and display image

clims = [7 52]; %Set color limit data values
thres = 125; %Set peak threshold value

%Call FastPeakFind function
p = FastPeakFind(cdata_647, thres, 1/9*ones(3,3), 5);
xpoints = p(1:2:end);   %assign x-values
ypoints = p(2:2:end);   %assign y-values

%Display image with peaks marked
figure(1)
imagesc(cdata_647,clims); 
hold on
plot(p(1:2:end),p(2:2:end),'k+') 

%% Pixel density filtering and display image

densityfactor = 55; %Absolute value for pixel distance surrounding ROIs
minimumpixels = 3;  %Minimum pixel number to conserve ROI

%Call FindROI_refiner function
[densepx, densepy] = FindROI_refiner(xpoints, ypoints, densityfactor, minimumpixels);

%Display image with reserved peaks
plot(densepx, densepy, 'r+'); 
hold off

%% Area calculations
break
%Calculating area by raw peak pixels
xreallength = 1;
[r, c] = size(cdata_647);
xpixellength = c;
realarea = length(densepx) * (2*densityfactor)^2 * pixelarea;
disp(['Total Pixel Area: ', num2str(realarea), ' um^2'])

%Compares pixels from FastPeakFind and FindROI_refiner
disp(['Black Pixels: ', num2str(length(xpoints))])
disp(['Red Pixels: ', num2str(length(densepx))])
pause(5)

%% ROI finder, setup for GaussFit code
%Creates multiple array files with subsets of the data centered at each
%pixel values in x and y and tests that the values are not at the edge of
%the image

num=size(cdata_647);
Imagesize=num(1);

pixel = 6;
subdata(:,:,1)=zeros(pixel*2+1,pixel*2+1);
k=1;

num=size(densepx);
num2=num(2);

for i=1:num2
    x=densepx(i);
    y=densepy(i);
    if x<(pixel*1.5)
    
    elseif y<(pixel*1.5)
        
    elseif x>(Imagesize-(pixel*1.5))
    
    elseif y>(Imagesize-(pixel*1.5))
        
    else
    value=cdata_647(y-pixel:y+pixel,x-pixel:x+pixel);
    subdata_647(:,:,k)=value;
    valx(k)=x;
    valy(k)=y;
    k=k+1;

    end
end

% Plots image and draws boxes after elimination
figure(3)
imagesc(cdata_647,clims)
colormap(map)

num=size(valx);
num2=num(2);

hold on
for i=1:num2
    rectangle('Position',[valx(i)-(pixel+1),valy(i)-(pixel+1),pixel*2+1,pixel*2+1],'LineWidth',2,'Edgecolor','g')
end
hold off 

%% Data storage 
%Save subdata and peak position values

subdata_647=double(subdata_647);

save('DataFile_647.mat','subdata_647','map')
save('PeakFits.mat','valx','valy')
save('Imagedata_647.mat','cdata_647')

%% Fit a 2D gaussian function to data
%% PURPOSE:  Fit a 2D gaussian centroid to simulated data
% Uses lsqcurvefit to fit
%
% INPUT:
% 
%   MdataSize: Size of nxn data matrix
%   x0 = [Amp,x0,wx,y0,wy,fi]: Inital guess parameters
%   x = [Amp,x0,wx,y0,wy,fi]: simulated centroid parameters
%   noise: noise in % of centroid peak value (x(1)
%   InterpolationMethod = 'nearest' or 'linear' or 'spline' or 'cubic'
%       used to calculate cross-section along minor and major axis
%     
%
%
% NOTE:
%   The initial values in x0 must be close to x in order for the fit
%   to converge to the values of x (especially if noise is added)
%
% OUTPUT:  non
%
% CREATED: G. Nootz  May 2012
% 
%  Modifications:
%  non
%% ---------User Input---------------------

% Load in 647 data file: cdata, subdata and xvals and yvals, the full image, ROI regions and the
% center x and y values

% load('DataFile_647.mat')
% load('PeakFits.mat')
% load('Imagedata_647.mat')

[pixel,ans1,ans2]=size(subdata_647);
pixel=pixel-1;
MdataSize = pixel; % Size of nxn data matrix
% parameters are: [Amplitude, x0, sigmax, y0, sigmay, background]
x0 = [30,0,.5,0,.5,0,1]; %Inital guess parameters
%x = [2,2.2,7,3.4,4.5,+0.02*2*pi]; %centroid parameters

InterpolationMethod = 'nearest'; % 'nearest','linear','spline','cubic'
FitForOrientation = 1;  %Turns off orientation fit

%create mesh size xdata, and xdatahr - high resolution
[X,Y] = meshgrid(-MdataSize/2:MdataSize/2);
xdata = zeros(size(X,1),size(Y,2),2);
xdata(:,:,1) = X;
xdata(:,:,2) = Y;
[Xhr,Yhr] = meshgrid(linspace(-MdataSize/2,MdataSize/2,300)); % generate high res grid for plot
xdatahr = zeros(300,300,2);
xdatahr(:,:,1) = Xhr;
xdatahr(:,:,2) = Yhr;

%actual data
num=size(valx);
num2=num(2);

for i=1:num2
    Z=subdata_647(:,:,i);
    
if FitForOrientation == 0
    % define lower and upper bounds [Amp,xo,wx,yo,wy,fi]
    lb = [0,-MdataSize/2,0,-MdataSize/2,0,-pi/4];
    ub = [realmax('double'),MdataSize/2,(MdataSize/2)^2,MdataSize/2,(MdataSize/2)^2,pi/4];
    [x,resnorm,residual,exitflag] = lsqcurvefit(@D2GaussFunctionRot,x0,xdata,Z,lb,ub);
else
    lb = [0,-MdataSize/2,0,-MdataSize/2,0,-x0(1)];
    ub = [realmax('double'),MdataSize/2,(MdataSize/2)^2,MdataSize/2,(MdataSize/2)^2,x0(1)];
    [x,resnorm,residual,exitflag] = lsqcurvefit(@D2GaussFunction,x0,xdata,Z,lb,ub);
    x_all(:,i)=x;
    resnorm_all(:,i)=resnorm;
    residual_all(:,:,i)=residual;
    exitflag_all(:,i)=exitflag;
end

%% Plot peak profiles
%This section will plot the fit curves and peak to evaluate the model

%limit the number to plot
if i<10 
hf2 = figure(i);
set(hf2, 'Position', [20 20 950 900])
alpha(0)
subplot(4,4, [5,6,7,9,10,11,13,14,15])
imagesc(X(1,:),Y(:,1)',Z)
set(gca,'YDir','reverse')
colormap('jet')

string1 = ['       Amplitude','    X-Coordinate', '    X-Width','    Y-Coordinate','    Y-Width','     Background'];
%string2 = ['Set     ',num2str(xin(1), '% 100.3f'),'             ',num2str(xin(2), '% 100.3f'),'         ',num2str(xin(3), '% 100.3f'),'         ',num2str(xin(4), '% 100.3f'),'        ',num2str(xin(5), '% 100.3f'),'     ',num2str(xin(6), '% 100.3f')];
string3 = ['Fit      ',num2str(x(1), '% 100.3f'),'             ',num2str(x(2), '% 100.3f'),'         ',num2str(x(3), '% 100.3f'),'         ',num2str(x(4), '% 100.3f'),'        ',num2str(x(5), '% 100.3f'),'        ',num2str(x(6), '% 100.3f')];

text(-MdataSize/2*0.9,+MdataSize/2*1.15,string1,'Color','red')
%text(-MdataSize/2*0.9,+MdataSize/2*1.2,string2,'Color','red')
text(-MdataSize/2*0.9,+MdataSize/2*1.25,string3,'Color','red')

%% Calculate cross sections

% generate points along horizontal axis
m = -tan(0);    % Point slope formula
b = (-m*x(2) + x(4));
xvh = -MdataSize/2:MdataSize/2;
yvh = xvh*m + b;
hPoints = interp2(X,Y,Z,xvh,yvh,InterpolationMethod);

% generate points along vertical axis
mrot = -m;
brot = (mrot*x(4) - x(2));
yvv = -MdataSize/2:MdataSize/2;
xvv = yvv*mrot - brot;
vPoints = interp2(X,Y,Z,xvv,yvv,InterpolationMethod);

hold on % Indicate major and minor axis on plot
% plot lines 
plot([xvh(1) xvh(size(xvh))],[yvh(1) yvh(size(yvh))],'r') 
plot([xvv(1) xvv(size(xvv))],[yvv(1) yvv(size(yvv))],'g') 
hold off

axis([-MdataSize/2-0.5 MdataSize/2+0.5 -MdataSize/2-0.5 MdataSize/2+0.5])

noise=.60;
ymin = - noise * x(1);
ymax = x(1)*(1+noise);
xdatafit = linspace(-MdataSize/2-0.5,MdataSize/2+0.5,300);
hdatafit = x(1)*exp(-(xdatafit-x(2)).^2/(2*x(3)^2))+x(6);
vdatafit = x(1)*exp(-(xdatafit-x(4)).^2/(2*x(5)^2))+x(6);
subplot(4,4, [1:3])
xposh = (xvh-x(2))/cos(0)+x(2);% correct for the longer diagonal if fi~=0
plot(xposh,hPoints,'r.',xdatafit,hdatafit,'black')
axis([-MdataSize/2-0.5 MdataSize/2+0.5 ymin*1.1 ymax*1.1])
subplot(4,4,[8,12,16])
xposv = (yvv-x(4))/cos(0)+x(4);% correct for the longer diagonal if fi~=0
plot(vPoints,xposv,'g.',vdatafit,xdatafit,'black')
axis([ymin*1.1 ymax*1.1 -MdataSize/2-0.5 MdataSize/2+0.5])
set(gca,'YDir','reverse')
figure(gcf) % bring current figure to front

else
    
end

end

%% Plot residuals of fit model

figure(50)
plot(resnorm_all)
title('Plot showing residuals of fit (647N)')
figure(51)
plot(x_all(3,:))
title('Plot showing widths of fit (647N)')

figure(30)
clims = [7 50];
imagesc(cdata_647,clims)
colormap(map)

figure(31)
imagesc(cdata_647,clims)
colormap(map)
hold on

num=size(valx);
num2=num(2);

for i=1:num2
    fitvalx_all(i)=valx(i)+x_all(2,i);
    fitvaly_all(i)=valy(i)+x_all(4,i);
    plot(fitvalx_all(i),fitvaly_all(i),'g*')
end

%Save data without removing residuals

fitvalx_all_orig=fitvalx_all;
fitvaly_all_orig=fitvaly_all;
x_all_orig=x_all;
resnorm_all_orig=resnorm_all;
residual_all_orig=residual_all;

%remove large residuals

reshigh=6000;
k=1;
for i=1:num2
    if resnorm_all(i)>reshigh
        outlier(k)=i;
        k=k+1;
    end
end

%remove large width value

w=2;

for i=1:num2
    if x_all(3,i)>w
        outlier(k)=i;
        k=k+1;
    end
end

outlier=unique(outlier);

resnorm_all(outlier)=[];
residual_all(outlier)=[];

figure(52)
plot(resnorm_all)

x_all(:,outlier)=[];

xmean=mean(x_all_orig(3,:))
ymean=mean(x_all_orig(5,:))
n_samp = length(x_all_orig(5,:))

figure(53)
imagesc(cdata_647,clims)
colormap(map)
hold on

%See which were removed

fitvalx_all(outlier)=[];
fitvaly_all(outlier)=[];

num=size(fitvalx_all);
num2=num(2);

for i=1:num2
    plot(fitvalx_all(i),fitvaly_all(i),'g*')
end

figure(54)
%Compare amplitude and width - see no correlation
plot(x_all(1,:),x_all(3,:),'g*')

%% Save data files for fit

fitvalx_all_647=fitvalx_all_orig;
fitvaly_all_647=fitvaly_all_orig;
x_all_647=x_all_orig;
resnorm_all_647=resnorm_all_orig;
residual_all_647=residual_all_orig;
outlier_647=outlier;

save('Finalxyvalues_647.mat','fitvalx_all_647','fitvaly_all_647')
save('Finalfitvalues_647.mat', 'x_all_647','resnorm_all_647','residual_all_647','outlier_647')